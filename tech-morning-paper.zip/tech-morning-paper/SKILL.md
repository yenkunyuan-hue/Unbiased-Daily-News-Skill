---
name: tech-morning-paper
description: Produce yen's daily 科技晨报: rank 8+ tech stories by impact plus weights, add pro/con views with sources and a Danish fun fact, and publish a weather-themed newspaper page.
---

# 科技晨报（每日科技新闻报纸）

为 yen 生成当天的科技新闻报纸。全文用中文写。所需文件（`template.html`、`build.py`、`config.json`，以及数据样例）在项目文件夹 `/mnt/project-files/tech-daily/`；完整的导出包在 `/mnt/project-files/tech-daily-skill/tech-morning-paper.zip`。如果工作目录里缺文件，先从导出包解压过去。

## 1. 选题范围

收录：
1. **AI 技术**：新模型发布与推广；AI 在某个领域落地并取得突破。
2. **AI 监管与地缘竞争**：美国、中国、欧洲三方平等覆盖。
3. **全球芯片产业**：全球视角（英伟达、台积电、英特尔、出口管制等），不专门看中国国产芯片。
4. **美国科技大厂**（谷歌、Meta、亚马逊、微软、苹果、OpenAI 等）。
5. **学术论文**：单独成条，和其他新闻一起按影响力排序，不附在别的新闻下面。
6. **网络安全、隐私、反垄断**：只在重大法案通过或落地时收录，否则不收。

不收录：消费电子（手机、数码产品）。

## 2. 选择与排序

- 只收过去 24 小时的新闻；每期**至少 8 条**。
- **不平衡领域**，只按“影响力 + 加权”排序，同一领域可以出多条。
- 加权项（四项权重相同）：
  - 欧洲相关新闻（丹麦与欧洲其他地方同等权重）
  - 具身智能 / 机器人
  - 大模型及相关领域
  - **顶会精选论文**：只给会议自己选出的核心论文加权，例如 CVPR/ICCV/ECCV 的 Highlight 与最佳论文（含提名），NeurIPS/ICML/ICLR 的 Oral、Spotlight、杰出论文奖，CoRL/RSS/ICRA 的最佳论文（含入围）与 Oral，ACL/EMNLP 的最佳或杰出论文。普通接收论文和 arXiv 预印本照常参与排序但不加权。
- 论文来源优先 AI 顶会，Nature/Science 往后放；会议之间具身智能（CoRL、RSS、ICRA）与机器学习（NeurIPS、ICML、ICLR）优先于视觉（CVPR 等）与语言（ACL 等）。
- 影响力用 1–5 分标注，属编辑判断。

## 3. 每条新闻的结构

- 发生了什么
- 为什么重要
- 正面观点（每条附来源）
- 负面或质疑观点（每条附来源）
- 来源比例（页面按 lang 字段自动统计英文 / 中文个数）

来源不限，但**中文互联网来源不得超过一半**。无法打开或核实的来源要明说；早于 24 小时但因加权收录的新闻要注明日期。

## 4. 丹麦冷知识

每期加一个丹麦冷知识，单独成栏，**不计入新闻条数**。要有可靠来源，不与以往各期重复（先查 `editions/*.json` 里已有的 `fact`）。写进 JSON 的 `fact` 字段：`title`、`text`、`source`、`url`。

## 5. 天气与版式

- 用 WebFetch 打开 `config.json` 里的 yr.no 链接取当天天气（Bash 访问外网可能被代理拦截，open-meteo 对 WebFetch 也不可用）。
- 规则：当天降水 ≥ 1 mm 或白天有雨 → `rainy`；无降水且白天晴或少云 → `sunny`；其余 → `cloudy`。
- 地点默认丹麦埃斯比约（Esbjerg）。yen 要换城市时，找到该城市的 yr.no 链接，更新 `config.json`。

## 6. 生成与发布

1. 参照 `example-edition.json`（或 `editions/` 里最新一期）的结构，写 `editions/<YYYY-MM-DD>.json`，期号 `edition` 加 1。字段：`date`、`dateZh`、`weekday`、`edition`、`weather`（condition、label、location、locationZh、summary、high、low、precip、wind、source、sourceUrl）、`stories[]`（type、category、boost、impact、short、headline、dek、what、why、refs、pro、con，论文可加 venue；每个来源带 name、url、lang）、`fact`。
2. 运行 `python3 build.py editions/<日期>.json`，生成 `newspaper.html`。
3. 用 Artifact 发布同一路径的 `newspaper.html`，保持报纸链接不变（当前为 https://claude.ai/artifact/EpfeyC65HdPDJJDHYQiN12），重新发布时不要传 icon。

页面结构：报头与天气框 → 今日要闻目录（标题、一句话说明、影响力条，可跳转）→ 头条与右侧栏（丹麦冷知识、全版来源语言比例、版面构成）→ 其余新闻两栏排列；每条底部有正反观点条和来源比例条。页面顶部可切换预览三种天气版式。

## 7. 推送

由定时任务每天丹麦时间 8:52 运行（cron `CRON_TZ=Europe/Copenhagen 52 8 * * *`），完成后在项目线程里发一条简短消息：天气和所用版式、头条三条标题、丹麦冷知识标题、报纸链接。

## 8. 与 yen 沟通

- 给选项时拆细、用编号列出，等 yen 选完再去搜索。
- yen 改规则时，同步更新项目记忆（tech-news-scope）、本流程涉及的文件和定时任务。
