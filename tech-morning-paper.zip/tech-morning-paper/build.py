"""Build the daily newspaper page: python3 build.py editions/YYYY-MM-DD.json
Injects the edition JSON into template.html and writes newspaper.html next to this script."""
import json
import sys
from pathlib import Path

here = Path(__file__).resolve().parent
edition = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
assert edition["weather"]["condition"] in ("sunny", "cloudy", "rainy")
data = json.dumps(edition, ensure_ascii=False).replace("</", "<\\/")
html = (here / "template.html").read_text(encoding="utf-8").replace("__EDITION__", data)
(here / "newspaper.html").write_text(html, encoding="utf-8")
print("wrote", here / "newspaper.html")
